from distutils.core import setup
setup(
    name='easygui',
    version='0.94',
    py_modules=['easygui'],
    )
