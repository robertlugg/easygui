from distutils.core import setup
setup(
    name='easygui',
    version='0.96',
    py_modules=['easygui'],
    )
